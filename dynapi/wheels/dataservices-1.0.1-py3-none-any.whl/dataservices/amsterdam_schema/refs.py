REFS = set(
    [
        "https://geojson.org/schema/Geometry.json",
        "https://geojson.org/schema/Point.json",
        "https://geojson.org/schema/Polygon.json",
        "https://schemas.data.amsterdam.nl/schema@v1.0#/definitions/id",
        "https://schemas.data.amsterdam.nl/schema@v1.0#/definitions/class",
        "https://schemas.data.amsterdam.nl/schema@v1.0#/definitions/dataset",
        "https://schemas.data.amsterdam.nl/schema@v1.0#/definitions/year",
        "https://schemas.data.amsterdam.nl/schema@v1.0#/definitions/uri",
    ]
)
