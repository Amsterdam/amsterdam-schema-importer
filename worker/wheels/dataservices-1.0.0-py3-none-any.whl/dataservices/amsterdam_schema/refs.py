REFS = set(
    [
        "https://geojson.org/schema/Geometry.json",
        "https://geojson.org/schema/Point.json",
        "https://geojson.org/schema/Polygon.json",
        "https://static.amsterdam.nl/schemas/schema@v1.0#/definitions/id",
        "https://static.amsterdam.nl/schemas/schema@v1.0#/definitions/class",
        "https://static.amsterdam.nl/schemas/schema@v1.0#/definitions/dataset",
        "https://static.amsterdam.nl/schemas/schema@v1.0#/definitions/year",
        "https://static.amsterdam.nl/schemas/schema@v1.0#/definitions/uri",
    ]
)
